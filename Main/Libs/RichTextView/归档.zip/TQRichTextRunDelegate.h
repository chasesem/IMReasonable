//
//  TQRichTextRunDelegate.h
//  TQRichTextViewDemo
//
//  Created by fuqiang on 2/28/14.
//  Copyright (c) 2014 fuqiang. All rights reserved.
//

#import "TQRichTextRun.h"

@interface TQRichTextRunDelegate : TQRichTextRun

@end
